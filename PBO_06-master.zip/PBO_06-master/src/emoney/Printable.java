package emoney;

public interface Printable {
    void print();
}
